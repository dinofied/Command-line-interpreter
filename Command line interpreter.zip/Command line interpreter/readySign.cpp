#include "readySign.h"


void readySign::setReadySign(std::string newSign) {

	this->sign = newSign;
}

std::string readySign::getReadySign() {

	return sign;

}